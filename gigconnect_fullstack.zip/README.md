GigConnect Fullstack (Node.js + MySQL + React)
==============================================
This bundle includes:
 - backend/  -> Express API with MySQL + file upload (uploads/)
 - frontend/ -> React app (src/GigConnect.js)

Quick steps:
 1. Import schema.sql into your MySQL server.
 2. In backend/, run npm install and start the server.
 3. In frontend/, run npm install and start React dev server.
 4. Open React app and it will talk to backend (default http://localhost:5000).

Files created on: /mnt/data/gigconnect_fullstack
