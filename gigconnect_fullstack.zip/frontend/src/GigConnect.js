import React, { useState, useEffect } from "react";

export default function GigConnect() {
  const [registeredUser, setRegisteredUser] = useState(null);
  const [user, setUser] = useState(null);
  const [page, setPage] = useState("register");
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    phone: "",
    dob: "",
    address: "",
    skills: "",
    photo: null,
  });
  const [documents, setDocuments] = useState([]);
  const API = process.env.REACT_APP_API || 'http://localhost:5000';

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (files) setForm({ ...form, [name]: files[0] });
    else setForm({ ...form, [name]: value });
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const fd = new FormData();
      for (const key of ['name','email','password','phone','dob','address','skills']) {
        fd.append(key, form[key]);
      }
      if (form.photo) fd.append('photo', form.photo);

      const res = await fetch(API + '/api/auth/register', {
        method: 'POST',
        body: fd
      });
      const data = await res.json();
      if (res.ok) {
        // fetch profile to get full user
        const profileRes = await fetch(API + '/api/auth/profile/' + data.id);
        const p = await profileRes.json();
        setRegisteredUser(p.user);
        setUser(p.user);
        setPage('profile');
      } else {
        alert(data.message || 'Register failed');
      }
    } catch (err) {
      console.error(err);
      alert('Error');
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(API + '/api/auth/login', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ email: form.email, password: form.password })
      });
      const data = await res.json();
      if (res.ok) {
        setUser(data.user);
        setPage('profile');
      } else {
        alert(data.message || 'Login failed');
      }
    } catch (err) {
      console.error(err);
      alert('Error');
    }
  };

  const handleLogout = () => {
    setUser(null);
    setPage("login");
    setForm({
      name: "",
      email: "",
      password: "",
      phone: "",
      dob: "",
      address: "",
      skills: "",
      photo: null,
    });
    setDocuments([]);
  };

  const handleDocumentUpload = async (e) => {
    const file = e.target.files[0];
    if (!file || !user) return;
    const fd = new FormData();
    fd.append('userId', user.id);
    fd.append('document', file);
    const res = await fetch(API + '/api/auth/upload', { method: 'POST', body: fd });
    if (res.ok) {
      // refresh documents
      fetchDocuments();
    } else {
      alert('Upload failed');
    }
  };

  const fetchDocuments = async () => {
    if (!user) return;
    const res = await fetch(API + '/api/auth/documents/' + user.id);
    const data = await res.json();
    if (res.ok) setDocuments(data.documents || []);
  };

  useEffect(() => { fetchDocuments(); }, [user]);

  // Styles as JS objects (same as before)
  const styles = {
    container: { minHeight: "100vh", backgroundColor: "#f7f7f7", display: "flex", flexDirection: "column", alignItems: "center", fontFamily: "Arial, sans-serif" },
    header: { width: "100%", backgroundColor: "#3498db", color: "#fff", textAlign: "center", padding: "1rem", fontSize: "2rem", fontWeight: "bold", boxShadow: "0 2px 4px rgba(0,0,0,0.1)" },
    main: { display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", flexGrow: 1, padding: "2rem" },
    form: { backgroundColor: "#fff", padding: "2rem", borderRadius: "1rem", boxShadow: "0 2px 4px rgba(0,0,0,0.1)", width: "100%", maxWidth: "400px", marginBottom: "2rem", display: "flex", flexDirection: "column" },
    formTitle: { fontSize: "1.5rem", fontWeight: "bold", marginBottom: "1rem", textAlign: "center" },
    input: { border: "1px solid #ddd", padding: "0.5rem", marginBottom: "1rem", width: "100%", borderRadius: "0.5rem" },
    fileLabel: { display: "block", marginBottom: "0.5rem", fontWeight: "bold" },
    submitButton: { backgroundColor: "#3498db", color: "#fff", padding: "0.5rem 1rem", border: "none", borderRadius: "0.5rem", cursor: "pointer", width: "100%", marginBottom: "0.5rem" },
    linkButton: { background: "none", border: "none", color: "#3498db", cursor: "pointer", textDecoration: "underline", fontSize: "0.9rem", marginTop: "0.5rem", alignSelf: "center" },
    profileContainer: { backgroundColor: "#fff", padding: "2rem", borderRadius: "1rem", boxShadow: "0 2px 4px rgba(0,0,0,0.1)", width: "100%", maxWidth: "500px" },
    profileTitle: { fontSize: "1.5rem", fontWeight: "bold", marginBottom: "1rem", textAlign: "center" },
    profilePhoto: { width: "100px", height: "100px", borderRadius: "50%", objectFit: "cover", margin: "0 auto 1rem" },
    logoutButton: { backgroundColor: "#e74c3c", color: "#fff", padding: "0.5rem 1rem", border: "none", borderRadius: "0.5rem", cursor: "pointer", width: "100%", marginTop: "1rem" },
    documentList: { listStyle: "disc", paddingLeft: "1rem", marginTop: "0.5rem" },
  };

  return (
    <div style={styles.container}>
      <header style={styles.header}>GigConnect</header>

      <main style={styles.main}>
        {/* Register */}
        {page === "register" && (
          <form onSubmit={handleRegister} style={styles.form}>
            <h2 style={styles.formTitle}>Register</h2>
            <input style={styles.input} name="name" placeholder="Full Name" onChange={handleChange} />
            <input style={styles.input} name="email" type="email" placeholder="Email" onChange={handleChange} />
            <input style={styles.input} name="password" type="password" placeholder="Password" onChange={handleChange} />
            <input style={styles.input} name="phone" placeholder="Phone Number" onChange={handleChange} />
            <input style={styles.input} name="dob" type="date" onChange={handleChange} />
            <textarea style={styles.input} name="address" placeholder="Address" onChange={handleChange} />
            <input style={styles.input} name="skills" placeholder="Technical Skills" onChange={handleChange} />
            <label style={styles.fileLabel}>Profile Photo:</label>
            <input type="file" name="photo" accept="image/*" onChange={handleChange} />
            <button type="submit" style={styles.submitButton}>Register</button>
            <button type="button" style={styles.linkButton} onClick={() => setPage("login")}>
              Already have an account? Login
            </button>
          </form>
        )}

        {/* Login */}
        {page === "login" && (
          <form onSubmit={handleLogin} style={styles.form}>
            <h2 style={styles.formTitle}>Login</h2>
            <input style={styles.input} name="email" type="email" placeholder="Email" onChange={handleChange} />
            <input style={styles.input} name="password" type="password" placeholder="Password" onChange={handleChange} />
            <button type="submit" style={styles.submitButton}>Login</button>
            <button type="button" style={styles.linkButton} onClick={() => setPage("register")}>
              Don't have an account? Register
            </button>
          </form>
        )}

        {/* Profile */}
        {page === "profile" && user && (
          <div style={styles.profileContainer}>
            <h2 style={styles.profileTitle}>Profile Page</h2>
            {user.photo && <img src={API + '/uploads/' + user.photo} alt="Profile" style={styles.profilePhoto} />}
            <p><b>Name:</b> {user.name}</p>
            <p><b>Email:</b> {user.email}</p>
            <p><b>Phone:</b> {user.phone}</p>
            <p><b>DOB:</b> {user.dob && user.dob.split('T')[0]}</p>
            <p><b>Address:</b> {user.address}</p>
            <p><b>Skills:</b> {user.skills}</p>

            <div>
              <label style={styles.fileLabel}>Post a Document (PDF/Image):</label>
              <input type="file" accept=".pdf,image/*" onChange={handleDocumentUpload} />
            </div>

            {documents.length > 0 && (
              <div>
                <h3>Uploaded Documents:</h3>
                <ul style={styles.documentList}>
                  {documents.map((doc, index) => (
                    <li key={index}>
                      <a href={API + '/uploads/' + doc.filename} target="_blank" rel="noreferrer">{doc.original_name}</a>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <button onClick={handleLogout} style={styles.logoutButton}>Logout</button>
          </div>
        )}
      </main>
    </div>
  );
}
