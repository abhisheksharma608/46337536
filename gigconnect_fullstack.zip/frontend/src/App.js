import React from 'react';
import GigConnect from './GigConnect';

export default function App() {
  return <GigConnect />;
}
