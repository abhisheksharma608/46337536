Frontend (React)
----------------
1. In frontend/ run:
    npm install
2. Set REACT_APP_API to backend URL if not localhost:5000
    export REACT_APP_API=http://localhost:5000
3. Start dev server:
    npm start
4. This project contains src/GigConnect.js - the main component.
