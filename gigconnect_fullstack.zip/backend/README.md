Backend (Node.js + Express + MySQL)
---------------------------------
1. Copy this project to your machine.
2. In backend/ run:
    npm install
3. Create a MySQL database or run schema.sql:
    mysql -u root -p < schema.sql
4. Set environment variables (optional) or edit db.js:
    DB_HOST, DB_USER, DB_PASSWORD, DB_NAME
5. Start server:
    npm start
6. Server endpoints:
    POST /api/auth/register  (multipart/form-data: fields name,email,password,..., photo)
    POST /api/auth/login     (JSON: { email, password })
    POST /api/auth/upload    (multipart/form-data: userId, document)
    GET  /api/auth/documents/:userId
    GET  /api/auth/profile/:id
