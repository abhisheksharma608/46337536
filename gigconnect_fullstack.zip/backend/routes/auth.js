const express = require('express');
const router = express.Router();
const pool = require('../db');
const multer = require('multer');
const bcrypt = require('bcrypt');

// multer setup
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    const unique = Date.now() + '-' + Math.round(Math.random()*1E9);
    cb(null, unique + '-' + file.originalname);
  }
});
const upload = multer({ storage });

// Register route (accepts photo)
router.post('/register', upload.single('photo'), async (req, res) => {
  try {
    const { name, email, password, phone, dob, address, skills } = req.body;
    const photo = req.file ? req.file.filename : null;

    // check existing
    const [rows] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
    if (rows.length) return res.status(400).json({ message: 'Email already registered' });

    const hashed = await bcrypt.hash(password, 10);
    const [result] = await pool.query(
      'INSERT INTO users (name,email,password,phone,dob,address,skills,photo) VALUES (?,?,?,?,?,?,?,?)',
      [name,email,hashed,phone,dob,address,skills,photo]
    );
    res.json({ id: result.insertId, message: 'Registered' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    if (!rows.length) return res.status(400).json({ message: 'Invalid credentials' });
    const user = rows[0];
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(400).json({ message: 'Invalid credentials' });

    // omit password
    delete user.password;
    res.json({ user });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// Upload document for user (multipart form): fields: userId, file
router.post('/upload', upload.single('document'), async (req, res) => {
  try {
    const { userId } = req.body;
    if (!req.file) return res.status(400).json({ message: 'No file' });

    await pool.query('INSERT INTO documents (user_id, filename, original_name) VALUES (?,?,?)', [
      userId, req.file.filename, req.file.originalname
    ]);
    res.json({ message: 'Uploaded', filename: req.file.filename });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get documents for a user
router.get('/documents/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const [rows] = await pool.query('SELECT id, original_name, filename FROM documents WHERE user_id = ?', [userId]);
    res.json({ documents: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get profile
router.get('/profile/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.query('SELECT id,name,email,phone,dob,address,skills,photo FROM users WHERE id = ?', [id]);
    if (!rows.length) return res.status(404).json({ message: 'Not found' });
    res.json({ user: rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
